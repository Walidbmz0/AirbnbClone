-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: lamp
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Logement`
--

DROP TABLE IF EXISTS `Logement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Logement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `prix` float NOT NULL DEFAULT '0',
  `taille` float NOT NULL DEFAULT '0',
  `couchages` int(11) NOT NULL DEFAULT '0',
  `image` varchar(128) NOT NULL,
  `adresse_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `type_logement_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `adresse_id` (`adresse_id`),
  KEY `type_logement_id` (`type_logement_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `Logement_ibfk_1` FOREIGN KEY (`adresse_id`) REFERENCES `adresse` (`id`),
  CONSTRAINT `Logement_ibfk_2` FOREIGN KEY (`type_logement_id`) REFERENCES `type_logement` (`id`),
  CONSTRAINT `Logement_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Logement`
--

LOCK TABLES `Logement` WRITE;
/*!40000 ALTER TABLE `Logement` DISABLE KEYS */;
INSERT INTO `Logement` VALUES (7,'Chateau magnifique','Bienvenue dans notre château du XVIIème siècle situé dans un parc verdoyant de plusieurs hectares. Entièrement rénové, il allie charme d\'antan et modernité pour vous offrir un séjour inoubliable.',430,233,4,'pexels-bruce-reyeschow-2525714.jpg',10,24,5),(8,'Appartement superbe','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s',120,40,3,'pexels-pixabay-271624.jpg',12,24,1),(9,'Maison magnifique ','Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.',320,129,4,'pexels-scott-webb-1029599.jpg',13,24,2),(12,'Petit chalet','There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form',133,26,2,'pexels-frans-van-heerden-723177.jpg',16,24,3),(13,'Grand chalet','There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form',257,79,7,'pexels-eberhard-grossgasteiger-1004682.jpg',17,24,3);
/*!40000 ALTER TABLE `Logement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LogementEquipement`
--

DROP TABLE IF EXISTS `LogementEquipement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LogementEquipement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logement_id` int(11) NOT NULL,
  `equipement_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_logement_logement` (`logement_id`),
  KEY `FK_logement_equipement` (`equipement_id`),
  CONSTRAINT `LogementEquipement_ibfk_1` FOREIGN KEY (`logement_id`) REFERENCES `Logement` (`id`),
  CONSTRAINT `LogementEquipement_ibfk_2` FOREIGN KEY (`equipement_id`) REFERENCES `equipement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LogementEquipement`
--

LOCK TABLES `LogementEquipement` WRITE;
/*!40000 ALTER TABLE `LogementEquipement` DISABLE KEYS */;
/*!40000 ALTER TABLE `LogementEquipement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adresse`
--

DROP TABLE IF EXISTS `adresse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adresse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pays` varchar(50) NOT NULL DEFAULT '',
  `ville` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adresse`
--

LOCK TABLES `adresse` WRITE;
/*!40000 ALTER TABLE `adresse` DISABLE KEYS */;
INSERT INTO `adresse` VALUES (1,'France','Perpignan'),(2,'effe','effe'),(3,'effe','effe'),(4,'effe','effe'),(5,'effe','effe'),(6,'dsdsd','edsds'),(7,'dsdsd','edsds'),(8,'zedez','dzeezd'),(9,'eee','eee'),(10,'Norvège','elne'),(11,'France','Perpignan'),(12,'France','Perpignan'),(13,'Allemagne','Berlin'),(14,'Allemagne','Berlin'),(15,'Allemagne','Berlin'),(16,'Suède','Stockholme'),(17,'Suède','Stockholme'),(18,'ee','ee');
/*!40000 ALTER TABLE `adresse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipement`
--

DROP TABLE IF EXISTS `equipement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  CONSTRAINT `equipement_ibfk_1` FOREIGN KEY (`id`) REFERENCES `Logement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipement`
--

LOCK TABLES `equipement` WRITE;
/*!40000 ALTER TABLE `equipement` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `logement_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `logement_id` (`logement_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`logement_id`) REFERENCES `Logement` (`id`),
  CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_logement`
--

DROP TABLE IF EXISTS `type_logement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_logement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_logement`
--

LOCK TABLES `type_logement` WRITE;
/*!40000 ALTER TABLE `type_logement` DISABLE KEYS */;
INSERT INTO `type_logement` VALUES (1,'Appartement'),(2,'Maison'),(3,'Chalet'),(4,'Chambre'),(5,'Chateau');
/*!40000 ALTER TABLE `type_logement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) DEFAULT NULL,
  `prenom` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `is_host` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Eric','Jedusor','Ericjedusor@gmail.com','ericj',1),(23,'Belmezouar','Belmezouar','faste-one@hotmail.fr','ec89bca96fc87258946ed7062b38cb4a776f0e3208bbd7f7ee5325f8a72dceadc0dff0bcaa6f957393762c307745bac475f795c4e4d3cf42b7cfd42fef6ca982',0),(24,'Delarue','Jacob','hyfazzhd@gmail.com','ec89bca96fc87258946ed7062b38cb4a776f0e3208bbd7f7ee5325f8a72dceadc0dff0bcaa6f957393762c307745bac475f795c4e4d3cf42b7cfd42fef6ca982',1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-15  7:57:50
